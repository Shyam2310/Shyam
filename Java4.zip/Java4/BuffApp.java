class A{
	public static void main(String ar[]){
			String s="Hello";
			String s1="Hello";
			String s2="Hello";
			String s3="Hello";
			StringBuffer sb=new StringBuffer("HelloWorld");
			sb = sb.delete(4,8);
			System.out.println("after del"+sb);
			sb = sb.append(s);
			System.out.println(sb);
			System.out.println(s==s1);
			System.out.println(s.equals(s1));
			System.out.println(s2==s3);
			System.out.println(s2.equals(s3));
			System.out.println(s2==s1);
			System.out.println(s2.equals(s1));
		//sop(s2.equals(s));
		//sop("another class1"+s.equals(Str1.s1);
		}
}
/*class Str1{

	string}*/