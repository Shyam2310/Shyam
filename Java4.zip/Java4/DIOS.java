import java.io.*;
class DIOS{
	
	public static void main(String ar[]) throws IOException{
		FileOutputStream f= new FileOutputStream("primitive.txt");
		DataOutputStream d= new DataOutputStream(f);
		float a=(float)20.33;
		d.writeBoolean(true);
		d.writeChar('a');
		d.writeInt(10);
		d.writeFloat((float)100,20);
		d.writeByte(12);
		d.close();
		
		FileOutputStream f= new FileOutputStream("primitive.txt");
		DataOutputStream d= new DataOutputStream(f);
		
		boolean b = di.readBoolean();
		char c = di.readChar();
		int i = di.readInt();
		float f1 = di.readFloat();
		byte by= di.readByte();
		
		System.out.println(b);
		System.out.println(c);
		System.out.println(i);
		System.out.println(f1);
		System.out.println(by);
		//System.out.println(b);
		
		
		di.close();
	}
}