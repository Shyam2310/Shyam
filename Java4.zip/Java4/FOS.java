import java.io.*;
class FOS{
	static int i;
	static FileInputStream f;
	static FileOutputStream fo;
	
	public static void main(String ar[]) throws IOException{
		String s="i m fine";
		byte b[]=s.getBytes();
		
		byte b1[]={90, 23};
		fo = new FileOutputStream("fine1.txt");
		f = new FileInputStream("fine1.txt");
		fo.write(b);
		fo.flush();
		fo.close();
		
		
		do{
			i = f.read();
			if (i!= -1){
				System.out.println((char)i);
			}
		}while(i!=-1);
	}
}