import java.io.*;
class A{
	public static void main(String[] ar) throws IOException{
		int i;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter your name: ");
		System.out.println("Name: "+br.readLine());
	}
}