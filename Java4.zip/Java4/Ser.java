import java.io.*;

class A implements Serializable{
	void show(){
		System.out.println("class A");
	}
}
class Serial{
	A a1;
	void writeData(){
		try{
			FileOutputStream f = new FileOutputStream("Serial.txt");
			ObjectOutputStream os = new ObjectOutputStream(f);
			
			String s[]={"hello","World"};
			int x = 10;
			int []y = {12, 123,12};
			
			os.writeObject(s);
			os.writeInt(x);
			os.writeObject(y);
			a1 = new A();
			os.writeObject(a1);
			os.close();
		}
		catch(IOException e){}
	}
	void readData(){
		try{
			FileInputStream fo = new FileInputStream("Serial.txt");
			ObjectInputStream oi = new ObjectInputStream(fo);
			String s1[] = (String[])oi.readObject();
			for(int i = 0; i <s1.lenght; i++)
			System.out.println(s1[i]);
			int p= oi.readInt();
			System.out.println(p);
			int y1[] = (int[])oi.readObject();
			for(int i=0; i<y1.lenght; i++)
			System.out.println(y1[i]);
		
			a1=(A)oi.readObject();
			a1.show();
			oi.close();
		}
		catch(Exception e){}
	}
	public static void main(String ar[]){
		Serial s = new Serial();
		s.writeData();
		s.readData();
	}
	os.writeObject(a1);
	
}
	
	