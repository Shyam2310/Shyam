class A extends Thread{
		A(){
			start();
		}
	public void run(){
			System.out.println("Hello");
			try{
			sleep(1000);
			}
			catch(InterruptedException e){
				System.out.println("child thread interrupted Hello");
			}
			System.out.println("bye");
		}
	}


class DemoThread{
	
	public static void main(String ar[]){
			A a = new A();
			A a1 = new A();			// Multi Thread
			/*Thread t= new Thread(a);
			Thread t1= new Thread(a1);
			t.start();
			t1.start(); */
	}
}