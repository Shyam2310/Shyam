class A{
	void s(){
		System.out.println("hello");
		try{
			Thread.sleep(1000);
		}
		catch(InterruptedException e){
			System.out.println("child thread interrupted Hello");
		}
		System.out.println("bye");
		}
			
	void s2()
	{
		System.out.println("s2");
	}
}
class Demo implements Runnable{
	int i;
	A a;
		Demo(A a){
			this.a = a;
		}
		public void run(){

	synchronized (a){
			a.s();
		}
	}
}

class DemoThread{
	
	public static void main(String ar[]){
			A a1 = new A();
			Demo d = new Demo(a1);			// Multi Thread
			Thread t,t1;
			t = new Thread(d);
			t.start();
			t1 = new Thread(d,"two");
			t1.start();
	}
}