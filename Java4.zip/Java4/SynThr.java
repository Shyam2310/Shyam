class A implements Runnable{
	/*int i;
	String n;
	A(){
		start();*/
		public void run(){
			show();
		}
	synchronized void show(){
			System.out.println("Hello");
			try{
			Thread.sleep(1000);
			}
			catch(InterruptedException e){
				System.out.println("child thread interrupted Hello");
			}
			System.out.println("bye");
		}
	}

class DemoThread{
	
	public static void main(String ar[]){
			A a = new A();
			A a1 = new A();			// Multi Thread
			Thread t= new Thread(a);
			Thread t1= new Thread(a);
			t.start();
			t1.start();
	}
}