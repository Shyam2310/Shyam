class A implements Runnable{
	int i;
	String n;
	public void run(){
		for(i=0; i<5; i++){
			System.out.println("child"+n+"i="+i);
			System.out.println("child thread"+n+"finished");
		}
	}
}
class DemoThread{
	
	public static void main(String ar[]){
			A a = new A();
			A a1 = new A();			// Multi Thread
			Thread t= new Thread(a);
			Thread t1= new Thread(a1);
			t.start();
			t1.start();
	}
}