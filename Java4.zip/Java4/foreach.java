class A{
	void dis(){
		int x[]={10, 20, 30};
		for(int i:x)
			System.out.println("i ="+i);
	}
	public static void main(String ar[]){
		A a1 = new A();
		a1.dis();
	}
}