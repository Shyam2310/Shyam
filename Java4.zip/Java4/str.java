class A{
	public static void main(String ar[]){
		
		String s1="Hello";
		String s2="Hello";
		String s3=new String("Hello");
		if (s1.equals(s2)){
		System.out.println("S1 is equal to S2");
		}
			else{
				System.out.println("S1 is not equal to s2");
			}
		if (s2.equals(s3)){
			System.out.println("S2 is equal to S3");
		}
		else{
			System.out.println("S2 is not equal to S3");
		}
			
	}
}